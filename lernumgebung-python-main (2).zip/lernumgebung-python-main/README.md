# Lernumgebung: Python

Willkommen in der Python Lernumgebung.

## Grafische Benutzeroberfläche

1. Im Browser http://localhost:6080 öffnen
1. Auf `Connect` drücken
1. Passwort `vscode` eingeben
1. In der Konsole von Visual Studio Code eine GUI-Applikation starten.
