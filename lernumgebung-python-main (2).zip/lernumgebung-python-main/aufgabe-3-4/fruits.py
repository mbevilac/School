transaktionen = [
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 4},
        {"artikel": "Apfel", "preis": 4.00, "menge": 6},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 1}
    ],
    [
        {"artikel": "Mandarine", "preis": 10.00, "menge": 9}
    ],
    [
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 5},
        {"artikel": "Orange", "preis": 2.50, "menge": 3},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Apfel", "preis": 4.00, "menge": 8},
        {"artikel": "Birne", "preis": 3.00, "menge": 4}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 2},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 1}
    ],
    [
        {"artikel": "Traube", "preis": 5.00, "menge": 3},
        {"artikel": "Orange", "preis": 2.50, "menge": 2}
    ],
    [
        {"artikel": "Birne", "preis": 3.00, "menge": 6}
    ],
    [
        {"artikel": "Apfel", "preis": 4.00, "menge": 5},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 3}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 4},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Mandarine", "preis": 10.00, "menge": 9},
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 5}
    ],
    [
        {"artikel": "Ananas", "preis": 6.50, "menge": 2},
        {"artikel": "Orange", "preis": 2.50, "menge": 4},
        {"artikel": "Apfel", "preis": 4.00, "menge": 3}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 3},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 1},
        {"artikel": "Apfel", "preis": 4.00, "menge": 2}
    ],
    [
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 4},
        {"artikel": "Birne", "preis": 3.00, "menge": 2},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 1}
    ],
    [
        {"artikel": "Mandarine", "preis": 10.00, "menge": 7},
        {"artikel": "Banane", "preis": 2.50, "menge": 5}
    ],
    [
        {"artikel": "Apfel", "preis": 4.00, "menge": 6},
        {"artikel": "Orange", "preis": 2.50, "menge": 3},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Birne", "preis": 3.00, "menge": 3},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 4}
    ],
    [
        {"artikel": "Mandarine", "preis": 10.00, "menge": 9},
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 5},
        {"artikel": "Birne", "preis": 3.00, "menge": 2}
    ],
    [
        {"artikel": "Apfel", "preis": 4.00, "menge": 8},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 3}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 2},
        {"artikel": "Orange", "preis": 2.50, "menge": 1}
    ],
    [
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 5},
        {"artikel": "Apfel", "preis": 4.00, "menge": 3},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 4},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 1}
    ],
    [
        {"artikel": "Mandarine", "preis": 10.00, "menge": 9}
    ],
    [
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 5},
        {"artikel": "Orange", "preis": 2.50, "menge": 3},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Apfel", "preis": 4.00, "menge": 8},
        {"artikel": "Birne", "preis": 3.00, "menge": 4}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 2},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 1}
    ],
    [
        {"artikel": "Traube", "preis": 5.00, "menge": 3},
        {"artikel": "Orange", "preis": 2.50, "menge": 2}
    ],
    [
        {"artikel": "Birne", "preis": 3.00, "menge": 6}
    ],
    [
        {"artikel": "Apfel", "preis": 4.00, "menge": 5},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 3}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 4},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Mandarine", "preis": 10.00, "menge": 9},
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 5}
    ],
    [
        {"artikel": "Ananas", "preis": 6.50, "menge": 2},
        {"artikel": "Orange", "preis": 2.50, "menge": 4},
        {"artikel": "Apfel", "preis": 4.00, "menge": 3}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 3},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 1},
        {"artikel": "Apfel", "preis": 4.00, "menge": 2}
    ],
    [
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 4},
        {"artikel": "Birne", "preis": 3.00, "menge": 2},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 1}
    ],
    [
        {"artikel": "Mandarine", "preis": 10.00, "menge": 7},
        {"artikel": "Banane", "preis": 2.50, "menge": 5}
    ],
    [
        {"artikel": "Apfel", "preis": 4.00, "menge": 6},
        {"artikel": "Orange", "preis": 2.50, "menge": 3},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Birne", "preis": 3.00, "menge": 3},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 4}
    ],
    [
        {"artikel": "Mandarine", "preis": 10.00, "menge": 9},
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 5},
        {"artikel": "Birne", "preis": 3.00, "menge": 2}
    ],
    [
        {"artikel": "Apfel", "preis": 4.00, "menge": 8},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 3}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 2},
        {"artikel": "Orange", "preis": 2.50, "menge": 1}
    ],
    [
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 5},
        {"artikel": "Apfel", "preis": 4.00, "menge": 3},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 4},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 1}
    ],
    [
        {"artikel": "Mandarine", "preis": 10.00, "menge": 9}
    ],
    [
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 5},
        {"artikel": "Orange", "preis": 2.50, "menge": 3},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Apfel", "preis": 4.00, "menge": 8},
        {"artikel": "Birne", "preis": 3.00, "menge": 4}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 2},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 1}
    ],
    [
        {"artikel": "Traube", "preis": 5.00, "menge": 3},
        {"artikel": "Orange", "preis": 2.50, "menge": 2}
    ],
    [
        {"artikel": "Birne", "preis": 3.00, "menge": 6}
    ],
    [
        {"artikel": "Apfel", "preis": 4.00, "menge": 5},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 3}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 4},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Mandarine", "preis": 10.00, "menge": 9},
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 5}
    ],
    [
        {"artikel": "Ananas", "preis": 6.50, "menge": 2},
        {"artikel": "Orange", "preis": 2.50, "menge": 4},
        {"artikel": "Apfel", "preis": 4.00, "menge": 3}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 3},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 1},
        {"artikel": "Apfel", "preis": 4.00, "menge": 2}
    ],
    [
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 4},
        {"artikel": "Birne", "preis": 3.00, "menge": 2},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 1}
    ],
    [
        {"artikel": "Mandarine", "preis": 10.00, "menge": 7},
        {"artikel": "Banane", "preis": 2.50, "menge": 5}
    ],
    [
        {"artikel": "Apfel", "preis": 4.00, "menge": 6},
        {"artikel": "Orange", "preis": 2.50, "menge": 3},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Birne", "preis": 3.00, "menge": 3},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 4}
    ],
    [
        {"artikel": "Mandarine", "preis": 10.00, "menge": 9},
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 5},
        {"artikel": "Birne", "preis": 3.00, "menge": 2}
    ],
    [
        {"artikel": "Apfel", "preis": 4.00, "menge": 8},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 3}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 2},
        {"artikel": "Orange", "preis": 2.50, "menge": 1}
    ],
    [
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 5},
        {"artikel": "Apfel", "preis": 4.00, "menge": 3},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 4},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 1}
    ],
    [
        {"artikel": "Mandarine", "preis": 10.00, "menge": 9}
    ],
    [
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 5},
        {"artikel": "Orange", "preis": 2.50, "menge": 3},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Apfel", "preis": 4.00, "menge": 8},
        {"artikel": "Birne", "preis": 3.00, "menge": 4}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 2},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 1}
    ],
    [
        {"artikel": "Traube", "preis": 5.00, "menge": 3},
        {"artikel": "Orange", "preis": 2.50, "menge": 2}
    ],
    [
        {"artikel": "Birne", "preis": 3.00, "menge": 6}
    ],
    [
        {"artikel": "Apfel", "preis": 4.00, "menge": 5},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 3}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 4},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Mandarine", "preis": 10.00, "menge": 9},
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 5}
    ],
    [
        {"artikel": "Ananas", "preis": 6.50, "menge": 2},
        {"artikel": "Orange", "preis": 2.50, "menge": 4},
        {"artikel": "Apfel", "preis": 4.00, "menge": 3}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 3},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 1},
        {"artikel": "Apfel", "preis": 4.00, "menge": 2}
    ],
    [
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 4},
        {"artikel": "Birne", "preis": 3.00, "menge": 2},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 1}
    ],
    [
        {"artikel": "Mandarine", "preis": 10.00, "menge": 7},
        {"artikel": "Banane", "preis": 2.50, "menge": 5}
    ],
    [
        {"artikel": "Apfel", "preis": 4.00, "menge": 6},
        {"artikel": "Orange", "preis": 2.50, "menge": 3},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Birne", "preis": 3.00, "menge": 3},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 4}
    ],
    [
        {"artikel": "Mandarine", "preis": 10.00, "menge": 9},
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 5},
        {"artikel": "Birne", "preis": 3.00, "menge": 2}
    ],
    [
        {"artikel": "Apfel", "preis": 4.00, "menge": 8},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 3}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 2},
        {"artikel": "Orange", "preis": 2.50, "menge": 1}
    ],
    [
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 5},
        {"artikel": "Apfel", "preis": 4.00, "menge": 3},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 4},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 1}
    ],
    [
        {"artikel": "Mandarine", "preis": 10.00, "menge": 9}
    ],
    [
        {"artikel": "Erdbeere", "preis": 3.50, "menge": 5},
        {"artikel": "Orange", "preis": 2.50, "menge": 3},
        {"artikel": "Pfirsich", "preis": 2.00, "menge": 2}
    ],
    [
        {"artikel": "Apfel", "preis": 4.00, "menge": 8},
        {"artikel": "Birne", "preis": 3.00, "menge": 4}
    ],
    [
        {"artikel": "Banane", "preis": 2.50, "menge": 2},
        {"artikel": "Kiwi", "preis": 2.00, "menge": 1}
    ]
]
