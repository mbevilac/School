Datenquelle: https://opendata.swiss/dataset/betreibungen-im-kanton-thurgau-nach-art-der-betreibungen
