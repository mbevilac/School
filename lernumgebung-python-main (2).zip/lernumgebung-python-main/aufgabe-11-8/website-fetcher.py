# 1. Programmbibliothek importieren

# 2. URL von der Konsole einlesen

# 3. HTML-Code der URL abrufen

# 4. Ausgabe des HTML-Code
