In dieser Aufgabe müssen Sie keinen Code abgeben. Es macht dennoch Sinn hier Ihr Ergebnis abzulegen.
