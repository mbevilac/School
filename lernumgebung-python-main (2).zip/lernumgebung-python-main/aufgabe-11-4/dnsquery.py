# 1. Programmbibliothek importieren

# 2. Einlesen des Hostname

# 3. Abrage der IP-Adresse über den DNS-Server 1.1.1.1

# 4. Ausgabe der erhaltenen IP-Adresse
